# Module 1 — Data Pipeline

## Objective

This module implements the required raw-to-relational pipeline for Zepto's catalog-style data workflow:

**Scrape → Clean → Convert → Normalize → SQLite → SQL queries → pandas validation**

The source is `https://books.toscrape.com/`, a public scraping-practice website.

## Requirements

Install the module dependencies:

```bash
pip install -r requirements.txt
```

## Run end to end

From this directory:

```bash
python pipeline.py
```

The script:

1. Scrapes the first 5 catalogue pages using `requests` and `BeautifulSoup`.
2. Fetches each book's product page to obtain its category.
3. Cleans the raw fields and creates the required typed columns.
4. Converts GBP to INR using the fixed assignment rate **1 GBP = 105.50 INR**.
5. Validates that at least 60 books and 3 categories were collected.
6. Creates/recreates `zepto_books.db` with the normalized `categories` and `books` tables.
7. Executes and saves five SQL queries and their outputs.
8. Loads multiple query results with `pd.read_sql()`.
9. Reproduces the JOIN independently using `pd.merge()` and records whether the outputs match.

No currency API is used. The required fixed conversion is applied directly:

```python
price_inr = price_gbp * 105.50
```

## Cleaning decisions

| Field | Cleaning | Result |
|---|---|---|
| `price` | Remove `£`, strip whitespace, numeric conversion | `price_gbp` as `float` |
| `star_rating` | Map One–Five to 1–5 | `rating` as `int` |
| `availability` | Search for `In stock` case-insensitively | `in_stock` as `bool` |
| `price_gbp` parse failures | Median imputation | Numeric field is not left missing |
| `rating` parse failures | Median imputation, rounded to nearest integer | Valid 1–5 integer |
| Missing `title`/`category` | Drop row | These are essential identifying fields |

The pipeline is defensive: malformed numeric values do not crash the run. Essential identifying fields are dropped because imputing a book title or category would create invented data.

## Database design

SQLite database: `zepto_books.db`

### `categories`

```sql
category_id INTEGER PRIMARY KEY
category_name TEXT UNIQUE NOT NULL
```

### `books`

```sql
book_id INTEGER PRIMARY KEY
title TEXT NOT NULL
price_gbp REAL NOT NULL
price_inr REAL NOT NULL
rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5)
in_stock INTEGER NOT NULL CHECK (in_stock IN (0,1))
category_id INTEGER NOT NULL REFERENCES categories(category_id)
```

The `books.category_id` foreign key references `categories.category_id`, avoiding repeated category names in every book record.

## Required SQL coverage

The script saves these queries under `outputs/`:

1. `01_select_where.sql` — `SELECT` + `WHERE`
2. `02_order_limit.sql` — `ORDER BY` + `LIMIT`
3. `03_distinct.sql` — `DISTINCT`
4. `04_between.sql` — `BETWEEN`
5. `05_join.sql` — relational `JOIN`

The corresponding query outputs are saved as CSV files.

## pandas validation

The script reads multiple SQL results using `pd.read_sql()` and saves them to:

- `outputs/join_read_sql.csv`
- `outputs/order_limit_read_sql.csv`

It separately reads the `books` and `categories` tables and uses:

```python
books.merge(cats, on="category_id")
```

The resulting JOIN is sorted and limited in the same way as the SQL query. The comparison result is recorded in `outputs/comparison.txt`, while the independent result is saved as `outputs/join_pd_merge.csv`.

## Generated artifacts

After a successful run, `data_pipeline/` contains:

- `zepto_books.db` — normalized SQLite database
- `outputs/cleaned_books.csv` — cleaned and converted dataset
- `outputs/*.sql` — saved SQL query strings
- `outputs/*.csv` — query outputs and pandas validation outputs
- `outputs/comparison.txt` — SQL/pandas JOIN equivalence result

## Acceptance checks

The script stops with an error if the scraped result contains fewer than 60 books or fewer than 3 categories. This ensures the required scope is enforced automatically rather than relying on manual inspection.
