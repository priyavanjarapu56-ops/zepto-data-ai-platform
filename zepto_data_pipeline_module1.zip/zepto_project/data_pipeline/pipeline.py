from __future__ import annotations

import re
import sqlite3
from pathlib import Path

import pandas as pd
import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/catalogue/page-{}.html"
GBP_TO_INR = 105.50
ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "zepto_books.db"
OUT = ROOT / "outputs"


def scrape_pages(num_pages: int = 5) -> pd.DataFrame:
    rows = []
    session = requests.Session()
    session.headers.update({"User-Agent": "ZeptoCapstone/1.0"})
    for page in range(1, num_pages + 1):
        r = session.get(BASE_URL.format(page), timeout=20)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        for card in soup.select("article.product_pod"):
            title = card.h3.a.get("title", "").strip()
            price = card.select_one(".price_color")
            rating = card.select_one("p.star-rating")
            availability = card.select_one(".availability")
            rows.append({
                "title": title,
                "price": price.get_text(strip=True) if price else "",
                "star_rating": "".join(rating.get("class", [])[1:]) if rating else "",
                "availability": availability.get_text(" ", strip=True) if availability else "",
                "category": "",  # filled from product detail page below
            })
            # The listing page does not expose category; fetch the product page.
            href = card.h3.a.get("href")
            if href:
                product_url = requests.compat.urljoin(BASE_URL.format(page), href)
                pr = session.get(product_url, timeout=20)
                pr.raise_for_status()
                ps = BeautifulSoup(pr.text, "html.parser")
                crumbs = ps.select(".breadcrumb li a")
                rows[-1]["category"] = crumbs[-1].get_text(strip=True) if crumbs else "Unknown"
    return pd.DataFrame(rows)


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["price_gbp"] = pd.to_numeric(
        out["price"].astype(str).str.replace("£", "", regex=False).str.strip(),
        errors="coerce",
    )
    rating_map = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
    out["rating"] = out["star_rating"].map(rating_map)
    out["in_stock"] = out["availability"].str.contains("In stock", case=False, na=False)

    # Essential text fields must be present; numeric parse failures use median as required.
    out = out.dropna(subset=["title", "category"])
    if out["price_gbp"].isna().any():
        out["price_gbp"] = out["price_gbp"].fillna(out["price_gbp"].median())
    if out["rating"].isna().any():
        out["rating"] = out["rating"].fillna(out["rating"].median()).round().astype(int)
    out["price_gbp"] = out["price_gbp"].astype(float)
    out["rating"] = out["rating"].astype(int)
    out["in_stock"] = out["in_stock"].astype(bool)
    out["price_inr"] = (out["price_gbp"] * GBP_TO_INR).round(2)
    return out[["title", "price_gbp", "price_inr", "rating", "in_stock", "category"]]


def create_db(df: pd.DataFrame) -> None:
    with sqlite3.connect(DB_PATH) as con:
        con.execute("PRAGMA foreign_keys = ON")
        con.executescript("""
        DROP TABLE IF EXISTS books;
        DROP TABLE IF EXISTS categories;
        CREATE TABLE categories (
            category_id INTEGER PRIMARY KEY,
            category_name TEXT UNIQUE NOT NULL
        );
        CREATE TABLE books (
            book_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            price_gbp REAL NOT NULL,
            price_inr REAL NOT NULL,
            rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
            in_stock INTEGER NOT NULL CHECK (in_stock IN (0,1)),
            category_id INTEGER NOT NULL REFERENCES categories(category_id)
        );
        """)
        cats = pd.DataFrame({"category_name": sorted(df["category"].unique())})
        cats.index = range(1, len(cats) + 1)
        cats.to_sql("categories", con, if_exists="append", index_label="category_id")
        cat_map = dict(zip(cats["category_name"], cats.index))
        books = df.copy()
        books["category_id"] = books["category"].map(cat_map)
        books["in_stock"] = books["in_stock"].astype(int)
        books = books[["title", "price_gbp", "price_inr", "rating", "in_stock", "category_id"]]
        books.to_sql("books", con, if_exists="append", index=False)


def run_queries() -> None:
    OUT.mkdir(exist_ok=True)
    queries = {
        "01_select_where": "SELECT title, price_gbp FROM books WHERE price_gbp > 20;",
        "02_order_limit": "SELECT title, price_gbp FROM books ORDER BY price_gbp DESC LIMIT 10;",
        "03_distinct": "SELECT DISTINCT rating FROM books ORDER BY rating;",
        "04_between": "SELECT title, price_gbp FROM books WHERE price_gbp BETWEEN 10 AND 20 ORDER BY price_gbp;",
        "05_join": "SELECT c.category_name, b.title, b.rating, b.price_gbp FROM books b JOIN categories c ON b.category_id = c.category_id ORDER BY b.rating DESC, c.category_name, b.title LIMIT 10;",
    }
    with sqlite3.connect(DB_PATH) as con:
        for name, sql in queries.items():
            result = pd.read_sql_query(sql, con)
            (OUT / f"{name}.sql").write_text(sql + "\n", encoding="utf-8")
            result.to_csv(OUT / f"{name}.csv", index=False)
            print(f"\n{name}\n{sql}\n{result.to_string(index=False)}")

    # Read at least two query results back into pandas with pd.read_sql.
    with sqlite3.connect(DB_PATH) as con:
        sql_df = pd.read_sql(queries["05_join"], con)
        sql_df_2 = pd.read_sql(queries["02_order_limit"], con)
    sql_df.to_csv(OUT / "join_read_sql.csv", index=False)
    sql_df_2.to_csv(OUT / "order_limit_read_sql.csv", index=False)

    # Reproduce the JOIN result independently with pandas merge (no SQL JOIN).
    with sqlite3.connect(DB_PATH) as con:
        books = pd.read_sql("SELECT * FROM books", con)
        cats = pd.read_sql("SELECT * FROM categories", con)
    merged = books.merge(cats, on="category_id")[["category_name", "title", "rating", "price_gbp"]]
    merged = merged.sort_values(["rating", "category_name", "title"], ascending=[False, True, True]).head(10)
    comparison = sql_df.reset_index(drop=True).equals(merged.reset_index(drop=True))
    print("\npd.read_sql vs pd.merge equivalent:", comparison)
    merged.to_csv(OUT / "join_pd_merge.csv", index=False)

    comparison_text = (
        "JOIN comparison: pd.read_sql result == pd.merge result -> "
        f"{comparison}\n\n"
        "The SQL JOIN result is saved as join_read_sql.csv and the independent "
        "pandas merge result is saved as join_pd_merge.csv.\n"
        "A second SQL result loaded with pd.read_sql is saved as "
        "order_limit_read_sql.csv.\n"
    )
    (OUT / "comparison.txt").write_text(comparison_text, encoding="utf-8")


def main() -> None:
    raw = scrape_pages(5)
    cleaned = clean_data(raw)
    if len(cleaned) < 60 or cleaned["category"].nunique() < 3:
        raise RuntimeError("Acceptance criterion not met: need >=60 books across >=3 categories")
    cleaned.to_csv(OUT / "cleaned_books.csv", index=False)
    create_db(cleaned)
    run_queries()
    print(f"Completed: {len(cleaned)} books, {cleaned['category'].nunique()} categories, fixed rate {GBP_TO_INR} INR/GBP")


if __name__ == "__main__":
    main()
